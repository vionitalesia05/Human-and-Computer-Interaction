document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('submissionForm');

  form.addEventListener('submit', function(event) {
    event.preventDefault(); // cegah submit default

    // Ambil elemen input
    const email = form.email.value.trim();
    const title = form.title.value.trim();
    const description = form.description.value.trim();
    const tags = form.tags.value;
    const aiGenerated = form.aiGenerated.value;
    const upload = form.upload.files[0];

    // Reset pesan error (jika Anda ingin menambahkan pesan error di UI, bisa dikembangkan)
    let errors = [];

    // Validasi email
    if (!email) {
      errors.push('Email harus diisi.');
    } else if (!validateEmail(email)) {
      errors.push('Format email tidak valid.');
    }

    // Validasi title
    if (!title) {
      errors.push('Title harus diisi.');
    }

    // Validasi description
    if (!description) {
      errors.push('Description harus diisi.');
    }

    // Validasi tags
    if (!tags) {
      errors.push('Tag harus dipilih.');
    }

    // Validasi AI-generated radio
    if (!aiGenerated) {
      errors.push('Harap pilih apakah artwork AI-generated.');
    }

    // Validasi file upload
    if (!upload) {
      errors.push('Harap upload file gambar.');
    } else if (!upload.type.startsWith('image/')) {
      errors.push('File yang diupload harus berupa gambar.');
    }

    // Jika ada error, tampilkan alert dan hentikan submit
    if (errors.length > 0) {
      alert('Terjadi kesalahan:\n- ' + errors.join('\n- '));
      return;
    }

    // Jika validasi berhasil, Anda bisa lanjutkan proses submit (misal kirim ke server)
    alert('Submission berhasil! Terima kasih sudah mengirim karya Anda.');

    // Contoh reset form setelah submit sukses
    form.reset();
  });

  // Fungsi validasi email sederhana
  function validateEmail(email) {
    // Cek format email sederhana tanpa regex
    return email.includes('@') && email.includes('.') && email.indexOf('@') < email.lastIndexOf('.');
  }
});
