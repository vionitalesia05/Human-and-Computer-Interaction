// Popup Romeo and Juliet
const romeoImg = document.getElementById('romeo-img');
const romeoPopup = document.getElementById('romeo-popup');
const popupCloseBtn = document.getElementById('popup-close-btn');

romeoImg.addEventListener('click', () => {
  romeoPopup.style.display = 'flex';
});

popupCloseBtn.addEventListener('click', () => {
  romeoPopup.style.display = 'none';
});

romeoPopup.addEventListener('click', (e) => {
  if (e.target === romeoPopup) {
    romeoPopup.style.display = 'none';
  }
});

// Popup The Reborn of a Phoenix
const phoenixImg = document.getElementById('phoenix-img');
const phoenixPopup = document.getElementById('popup-phoenix');
const phoenixCloseBtn = document.getElementById('popup-phoenix-close');

phoenixImg.addEventListener('click', () => {
  phoenixPopup.style.display = 'flex';
});

phoenixCloseBtn.addEventListener('click', () => {
  phoenixPopup.style.display = 'none';
});

phoenixPopup.addEventListener('click', (e) => {
  if (e.target === phoenixPopup) {
    phoenixPopup.style.display = 'none';
  }
});

// Popup A Glass of Wine 
const wineImg = document.getElementById('wine-img');
const winePopup = document.getElementById('popup-wine');
const wineCloseBtn = document.getElementById('popup-wine-close');

wineImg.addEventListener('click', () => {
  winePopup.style.display = 'flex';
});

wineCloseBtn.addEventListener('click', () => {
  winePopup.style.display = 'none';
});

winePopup.addEventListener('click', (e) => {
  if (e.target === winePopup) {
    winePopup.style.display = 'none';
  }
});
